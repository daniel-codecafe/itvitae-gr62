package com.jorisvanbreugel.les3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Les3Application {

    public static void main(String[] args) {
        SpringApplication.run(Les3Application.class, args);
    }

}
