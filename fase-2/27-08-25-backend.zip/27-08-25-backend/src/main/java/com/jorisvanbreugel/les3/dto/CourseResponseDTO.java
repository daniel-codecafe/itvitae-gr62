package com.jorisvanbreugel.les3.dto;

public record CourseResponseDTO(
        Long id,
        String name
) {}
