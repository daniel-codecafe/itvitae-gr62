package com.jorisvanbreugel.les3.dto;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import org.springframework.context.annotation.Bean;
import org.springframework.lang.NonNull;

public record CourseCreateDTO(
        @NotNull
        @NotBlank
        String name
) {};