package com.jorisvanbreugel.les3.mappers;

import com.jorisvanbreugel.les3.dto.CourseCreateDTO;
import com.jorisvanbreugel.les3.dto.CourseResponseDTO;
import com.jorisvanbreugel.les3.models.Course;

import java.util.List;

public class CourseMapper {
    public static CourseResponseDTO toResponseDTO(Course course) {
        return new CourseResponseDTO(
                course.getId(), course.getName()
        );
    }

    public static CourseCreateDTO toCreateDTO(Course course) {
        return new CourseCreateDTO(
                course.getName()
        );
    }

    public static List<CourseResponseDTO> toResponseListDTO(List<Course> courses) {
        return courses.stream().map(CourseMapper::toResponseDTO).toList();
    }
}
